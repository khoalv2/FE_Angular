import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sidebar-footer',
  templateUrl: './app-sidebar-footer.component.html',
  styleUrls: ['./app-sidebar-footer.component.css']
})
export class AppSidebarFooterComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
