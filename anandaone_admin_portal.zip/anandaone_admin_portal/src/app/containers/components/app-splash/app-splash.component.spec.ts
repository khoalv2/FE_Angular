import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AppSplashComponent } from './app-splash.component';

describe('AppSplashComponent', () => {
  let component: AppSplashComponent;
  let fixture: ComponentFixture<AppSplashComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AppSplashComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AppSplashComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
