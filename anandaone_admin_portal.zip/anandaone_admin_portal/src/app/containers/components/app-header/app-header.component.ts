import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Globals } from '../../../global';
import { AnandaOneThemeService } from '../../../main/services/theme.service';

@Component({
  selector: 'app-header',
  templateUrl: './app-header.component.html',
  styleUrls: ['./app-header.component.scss']
})
export class AppHeaderComponent implements OnInit {

  isDarkTheme;
  returnUrl: string;
  constructor(
    public globals: Globals,
    public _anandaOneThemeService: AnandaOneThemeService,
    private route: ActivatedRoute,
    private router: Router,
  ) {
    this.isDarkTheme = globals;
  }

  ngOnInit() {

    if (this.isDarkTheme.isDarkTheme === null || this.isDarkTheme.isDarkTheme === 'false') {
      this._anandaOneThemeService.setValueTheme(false);
      this._anandaOneThemeService.setLightTheme();
    } else {
      this._anandaOneThemeService.setValueTheme(true);
      this._anandaOneThemeService.isDarkTheme();
    }

    // get return url from route parameters or default to '/'
    this.returnUrl = this.route.snapshot.queryParams['returnUrl'] || '/';
  }

  onClick(module) {
    if (module === 'logout') {
      this.returnUrl = '/login'
    }

    this.router.navigate([this.returnUrl]);
  }

}
