// tslint:disable-next-line:eofline
export * from './app-sidebar-minimizer.component';