import { query } from '@angular/animations';
import { Component, OnInit } from '@angular/core';
import { CONSTANTS } from '../../../main/const/constants';
import { SharedService } from '../../../main/services/shared.service';

@Component({
  selector: 'app-sidebar-header',
  templateUrl: './app-sidebar-header.component.html',
  styleUrls: ['./app-sidebar-header.component.scss']
})
export class AppSidebarHeaderComponent implements OnInit {

  activeButton;
  message: string;

  constructor(
    private sharedService: SharedService
  ) { }

  ngOnInit() {
    var btn = document.getElementById('btn-amc');
    btn.classList.add('btn-active');
    this.sharedService.sharedMessage.subscribe(message => this.message = CONSTANTS.ProjectType.AMC);
  }

  clickButton(event) {
    var btnASL = document.getElementById('btn-asl');
    var btnAMC = document.getElementById('btn-amc');
    this.activeButton = event;
    let projectType = CONSTANTS.ProjectType.ASL;

    if (event === CONSTANTS.ProjectType.ASL) {
      btnASL.classList.add('btn-active');
      btnAMC.classList.remove('btn-active');
    } else {
      btnAMC.classList.add('btn-active');
      btnASL.classList.remove('btn-active');
      projectType = CONSTANTS.ProjectType.AMC;
    }

    this.sharedService.nextMessage(projectType);
  }

}
