import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PoolEarningsComponent } from './pool-earnings/pool-earnings.component';
import { VoyageEarningsComponent } from './voyage-earnings/voyage-earnings.component';


const routes: Routes = [
  {
    path: '',
    data: {
      title: 'earnings'
    },
    children: [
      {
        path: '',
        redirectTo: 'pool-earnings'
      },
      {
        path: 'pool-earnings',
        component: PoolEarningsComponent,
        data: {
          title: 'PoolEarnings'
        }
      } ,
      {
        path: 'voyage-earnings',
        component: VoyageEarningsComponent,
        data: {
          title: 'VoyageEarnings'
        }
      }
    
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EarningsRoutingModule {}
