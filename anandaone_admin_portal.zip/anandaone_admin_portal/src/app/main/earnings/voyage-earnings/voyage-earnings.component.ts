import { Component, OnInit, TemplateRef, ElementRef, HostListener } from '@angular/core';

@Component({
  selector: 'app-voyage-earnings',
  templateUrl: './voyage-earnings.component.html',
  styleUrls: ['./voyage-earnings.component.css']
})
export class VoyageEarningsComponent implements OnInit {
  isShowFilter:boolean = false;
  isShowSetting:boolean = false;
  constructor() { }
  ngOnInit(): void {
  }
 
  toggleFilter(){
    this.isShowFilter =!this.isShowFilter;
  }

  toggleSetting(){
    this.isShowSetting =!this.isShowSetting;
  }
  
  handle(){
    alert("xin chào");
  }
}
