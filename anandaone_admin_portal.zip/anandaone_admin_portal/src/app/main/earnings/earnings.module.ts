import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { VoyageEarningsComponent } from './voyage-earnings/voyage-earnings.component';
import { PoolEarningsComponent } from './pool-earnings/pool-earnings.component';
import { EarningsRoutingModule } from './earnings.routing';
import { ComponentsModule } from '../components/components.module';
import { ChartsModule } from 'ng2-charts';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule } from 'ngx-bootstrap/modal';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { CheckOutSiteFilterDirective } from './check-outsite-filter.directive';
import {  CheckOutSideSettingDirective } from './check-outside-setting.directive';
@NgModule({
  declarations: [VoyageEarningsComponent,PoolEarningsComponent,CheckOutSiteFilterDirective,CheckOutSideSettingDirective],
  imports: [
    CommonModule,
    EarningsRoutingModule,
    ModalModule.forRoot(),
    ComponentsModule,
    ChartsModule,
    
    // BrowserAnimationsModule
  
  ],
})
export class EarningsModule { }
