import { Directive, ElementRef, HostListener, Input, Output, EventEmitter } from '@angular/core';

@Directive({
  selector: '[clickOutsideSetting]'
})
export class CheckOutSideSettingDirective {

  constructor(private _elementRef: ElementRef) { }

  @Output('clickOutsideSetting') clickOutside: EventEmitter<any> = new EventEmitter();

  @HostListener('document:click', ['$event.target']) onMouseEnter(targetElement) {
    const elementModalFilter: HTMLElement = document.getElementById("modalSetting");
    if(elementModalFilter!=null){
      const clickedInside = this._elementRef.nativeElement.contains(targetElement);
      if (!clickedInside && (!elementModalFilter.contains(targetElement)&& elementModalFilter)) {
        this.clickOutside.emit(null);
      }
    }
  
  }

}
