import { Directive, ElementRef, HostListener, Input, Output, EventEmitter } from '@angular/core';

@Directive({
  selector: '[clickOutside]'
})
export class CheckOutSiteFilterDirective {

  constructor(private _elementRef: ElementRef) { }

  @Output('clickOutside') clickOutside: EventEmitter<any> = new EventEmitter();
  @Input() modalType: number ;
  @HostListener('document:click', ['$event.target']) onMouseEnter(targetElement) {
    const elementModalFilter: HTMLElement = document.getElementById("modalFilter");
    
    if(elementModalFilter!=null){
      const clickedInside = this._elementRef.nativeElement.contains(targetElement);
      if (!clickedInside && (!elementModalFilter.contains(targetElement)&& elementModalFilter)) {
        this.clickOutside.emit(null);
      }
    }
  
  }


}
