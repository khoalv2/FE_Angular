import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PaymentFileListComponent } from './payment-file-list/payment-file-list.component';


const routes: Routes = [
  {
    path: '',
    component: PaymentFileListComponent,
    data: {
      title: 'Payment File Upload'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PaymentFileRoutingModule { }
