import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaymentFileListComponent } from './payment-file-list.component';

describe('PaymentFileListComponent', () => {
  let component: PaymentFileListComponent;
  let fixture: ComponentFixture<PaymentFileListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaymentFileListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaymentFileListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
