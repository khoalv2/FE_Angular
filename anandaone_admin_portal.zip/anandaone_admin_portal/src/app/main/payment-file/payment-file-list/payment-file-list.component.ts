import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-payment-file-list',
  templateUrl: './payment-file-list.component.html',
  styleUrls: ['./payment-file-list.component.scss']
})
export class PaymentFileListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
