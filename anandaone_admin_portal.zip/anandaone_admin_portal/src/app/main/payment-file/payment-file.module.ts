import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { PaymentFileRoutingModule } from './payment-file-routing.module';
import { PaymentFileListComponent } from './payment-file-list/payment-file-list.component';


@NgModule({
  declarations: [PaymentFileListComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    PaymentFileRoutingModule
  ]
})
export class PaymentFileModule { }
