import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { ReportRoutingModule } from './report-routing.module';
import { ReportComponent } from './report/report.component';


@NgModule({
  declarations: [ReportComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ReportRoutingModule
  ]
})
export class ReportModule { }
