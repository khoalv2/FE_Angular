import { Component, OnInit } from '@angular/core';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

@Component({
  selector: 'app-pool-vessels',
  templateUrl: './pool-vessels.component.html',
  styleUrls: ['./pool-vessels.component.css']
})
export class PoolVesselsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
    this.drawChart();
    this.hiddenLogoArmchart();
  }

  drawChart() {
    var chart = am4core.create("showChartVesselPosition", am4charts.PieChart);

    // Add data
    chart.data = [
      {
        "country": "Lithuania",
        "litres": 65,
        "color": am4core.color("#1EA7AC")
      },
      {
        "country": "Lithuania 2",
        "litres": 35,
        "color": am4core.color("#D0EBEC")
      }
    ];

    // Add and configure Series
    var pieSeries = chart.series.push(new am4charts.PieSeries());
    pieSeries.dataFields.value = "litres";
    pieSeries.dataFields.category = "country";
    pieSeries.dataFields.hidden = "hidden";

    chart.innerRadius = am4core.percent(58);

    let label = chart.seriesContainer.createChild(am4core.Label);
    label.text = "65";
    label.horizontalCenter = "middle";
    label.verticalCenter = "middle";
    label.fontSize = 25;
    label.fontWeight = "bold";
    label.fill = am4core.color("#1EA7AC");

    pieSeries.labels.template.disabled = true;
    pieSeries.ticks.template.disabled = true;
    pieSeries.slices.template.stroke = am4core.color("#1EA7AC");
    pieSeries.slices.template.fill = am4core.color("#1EA7AC");
    pieSeries.slices.template.tooltipText = "";
    pieSeries.dataFields.hidden = "hidden";
    pieSeries.slices.template.propertyFields.fill = "color";
    pieSeries.slices.template.propertyFields.stroke = "color";    

    pieSeries.slices.template.tooltipText = "";
    let hsHover = pieSeries.slices.template.states.getKey("hover");
    hsHover.properties.scale = 1;

    let hsActive = pieSeries.slices.template.states.getKey("active");
    hsActive.properties.shiftRadius = 0;
  }

  hiddenLogoArmchart(): void {
    var a = document.querySelectorAll('[aria-labelledby="id-236-title"]')
    if (a.length == 1) {
      a[0].setAttribute("display", "none");
    }
  }
}
