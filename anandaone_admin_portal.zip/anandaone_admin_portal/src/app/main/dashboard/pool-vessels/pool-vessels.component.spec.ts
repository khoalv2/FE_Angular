import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PoolVesselsComponent } from './pool-vessels.component';

describe('PoolVesselsComponent', () => {
  let component: PoolVesselsComponent;
  let fixture: ComponentFixture<PoolVesselsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PoolVesselsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PoolVesselsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
