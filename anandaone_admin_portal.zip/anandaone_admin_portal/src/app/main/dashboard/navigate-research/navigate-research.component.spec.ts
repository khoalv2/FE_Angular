import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NavigateResearchComponent } from './navigate-research.component';

describe('NavigateResearchComponent', () => {
  let component: NavigateResearchComponent;
  let fixture: ComponentFixture<NavigateResearchComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NavigateResearchComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NavigateResearchComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
