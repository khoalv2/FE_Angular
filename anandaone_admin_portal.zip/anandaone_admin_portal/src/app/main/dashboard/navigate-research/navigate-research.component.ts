import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navigate-research',
  templateUrl: './navigate-research.component.html',
  styleUrls: ['./navigate-research.component.css']
})
export class NavigateResearchComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
