import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LastestAvegragePoolEarningsComponent } from './lastest-avegrage-pool-earnings.component';

describe('LastestAvegragePoolEarningsComponent', () => {
  let component: LastestAvegragePoolEarningsComponent;
  let fixture: ComponentFixture<LastestAvegragePoolEarningsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LastestAvegragePoolEarningsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LastestAvegragePoolEarningsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
