import { Component, OnInit } from '@angular/core';
import * as am4core from "@amcharts/amcharts4/core";
import * as am4charts from "@amcharts/amcharts4/charts";
import am4themes_animated from "@amcharts/amcharts4/themes/animated";

@Component({
  selector: 'app-lastest-avegrage-pool-earnings',
  templateUrl: './lastest-avegrage-pool-earnings.component.html',
  styleUrls: ['./lastest-avegrage-pool-earnings.component.css']
})
export class LastestAvegragePoolEarningsComponent implements OnInit {
  isCheckButton: boolean = true;
  constructor() { }

  ngOnInit(): void {
    this.isCheckButton = true;
    this.drawChart();
    this.hiddenLogoArmchart();
  }

  hiddenLogoArmchart(): void {
    var a = document.querySelectorAll('[aria-labelledby="id-66-title"]')
    if (a.length == 1) {
      a[0].setAttribute("display", "none");
    }
  }

  clickButton(type: boolean) {
    if (type) {
      this.isCheckButton = true;
    } else {
      this.isCheckButton = false;
    }
  }

  drawChart(): void {

    am4core.useTheme(am4themes_animated);

    let chart = am4core.create("showChart", am4charts.XYChart);

    let data = [];

    chart.colors.list = [am4core.color("cyan")];

    chart.data = [{
      "Month": "Dec 19",
      "FixedPC": "100%",
      "TCE": 11645,
    }, {
      "Month": "Jan 20",
      "FixedPC": "99%",
      "TCE": 25645,
    }, {
      "Month": "Feb 20",
      "FixedPC": "10%",
      "TCE": 20645,
    }, {
      "Month": "Mar 20",
      "FixedPC": "55%",
      "TCE": 26645,
    }, {
      "Month": "Apr 20",
      "FixedPC": "70%",
      "TCE": 22645,
    }];


    let categoryFixedPC = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryFixedPC.renderer.grid.template.location = 0;
    categoryFixedPC.renderer.ticks.template.disabled = true;
    categoryFixedPC.renderer.line.opacity = 0;
    categoryFixedPC.renderer.grid.template.disabled = true;
    categoryFixedPC.renderer.minGridDistance = 30;
    categoryFixedPC.dataFields.category = "FixedPC";
    categoryFixedPC.startLocation = 0.4;
    categoryFixedPC.endLocation = 0.6;
    categoryFixedPC.renderer.labels.template.fontFamily = "Roboto";
    categoryFixedPC.renderer.labels.template.fontSize = 10;
    categoryFixedPC.renderer.labels.template.fill = am4core.color("#333333");
    categoryFixedPC.renderer.dy = 5;

    let categoryTCE = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryTCE.renderer.grid.template.location = 0;
    categoryTCE.renderer.ticks.template.disabled = true;
    categoryTCE.renderer.line.opacity = 0;
    categoryTCE.renderer.grid.template.disabled = true;
    categoryTCE.renderer.minGridDistance = 30;
    categoryTCE.dataFields.category = "TCE";
    categoryTCE.startLocation = 0.4;
    categoryTCE.endLocation = 0.6;
    categoryTCE.renderer.labels.template.fontWeight = "bold";
    categoryTCE.renderer.labels.template.fontFamily = "Roboto";
    categoryTCE.renderer.labels.template.fontSize = 12;
    categoryTCE.renderer.numberFormatter.numberFormat = "$#,###";
    categoryTCE.renderer.labels.template.fill = am4core.color("#1EA7AC");
    categoryTCE.renderer.maxLabelPosition = 1;
    categoryTCE.renderer.minLabelPosition = 0;
    categoryTCE.renderer.dy = 20;
    categoryTCE.renderer.dx = 0;
    categoryTCE.renderer.inside = true;

    let categoryMonth = chart.xAxes.push(new am4charts.CategoryAxis());
    categoryMonth.renderer.grid.template.location = 0;
    categoryMonth.renderer.ticks.template.disabled = true;
    categoryMonth.renderer.line.opacity = 0;
    categoryMonth.renderer.grid.template.disabled = true;
    categoryMonth.renderer.minGridDistance = 30;
    categoryMonth.dataFields.category = "Month";
    categoryMonth.startLocation = 0.4;
    categoryMonth.endLocation = 0.6;
    categoryMonth.renderer.labels.template.fontFamily = "Roboto";
    categoryMonth.renderer.labels.template.fontSize = 12;
    categoryMonth.renderer.labels.template.fill = am4core.color("#666666");

    let valueTCE = chart.yAxes.push(new am4charts.ValueAxis());
    valueTCE.renderer.grid.template.disabled = true;
    valueTCE.renderer.line.disabled = true;
    valueTCE.renderer.labels.template.disabled = true;
    valueTCE.tooltip.disabled = true;
    valueTCE.renderer.line.opacity = 0;
    valueTCE.renderer.ticks.template.disabled = true;
    valueTCE.renderer.inside = true;

    let lineSeries = chart.series.push(new am4charts.LineSeries());
    lineSeries.dataFields.categoryX = "FixedPC";
    lineSeries.dataFields.valueY = "TCE";
    lineSeries.tooltipText = "TCE: {valueY.value}";
    lineSeries.fillOpacity = 0.1;
    lineSeries.strokeWidth = 0;

    let bullet = lineSeries.bullets.push(new am4charts.CircleBullet());
    bullet.circle.radius = 1;
    bullet.circle.fill = am4core.color("#1ea7ac");
    bullet.circle.stroke = am4core.color("#1ea7ac");
    bullet.circle.strokeWidth = 3;
  }
}
