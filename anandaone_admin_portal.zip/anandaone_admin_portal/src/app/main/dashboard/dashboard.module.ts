import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { ChartsModule } from 'ng2-charts';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ButtonsModule } from 'ngx-bootstrap/buttons';
import { DashboardComponent } from './dashboard.component';
import { DashboardRoutingModule } from './dashboard-routing.module';
import { LastestAvegragePoolEarningsComponent } from './lastest-avegrage-pool-earnings/lastest-avegrage-pool-earnings.component';
import { MarketUpdatesComponent } from './market-updates/market-updates.component';
import { LastestPoolReportsComponent } from './lastest-pool-reports/lastest-pool-reports.component';
import { NavigateResearchComponent } from './navigate-research/navigate-research.component';
import { PoolVesselsComponent } from './pool-vessels/pool-vessels.component';
import { MyStemsComponent } from './my-stems/my-stems.component';
import { ComponentsModule } from '../components/components.module';

@NgModule({
  imports: [
    FormsModule,
    DashboardRoutingModule,
    ChartsModule,
    BsDropdownModule,
    ButtonsModule.forRoot(),
    ComponentsModule
  ],

  declarations: [DashboardComponent, LastestAvegragePoolEarningsComponent, MarketUpdatesComponent,
     LastestPoolReportsComponent, NavigateResearchComponent, PoolVesselsComponent, MyStemsComponent]
})
export class DashboardModule { }
