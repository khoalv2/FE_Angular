import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-lastest-pool-reports',
  templateUrl: './lastest-pool-reports.component.html',
  styleUrls: ['./lastest-pool-reports.component.css']
})
export class LastestPoolReportsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
