import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LastestPoolReportsComponent } from './lastest-pool-reports.component';

describe('LastestPoolReportsComponent', () => {
  let component: LastestPoolReportsComponent;
  let fixture: ComponentFixture<LastestPoolReportsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LastestPoolReportsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LastestPoolReportsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
