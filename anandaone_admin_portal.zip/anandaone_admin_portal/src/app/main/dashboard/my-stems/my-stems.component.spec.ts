import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MyStemsComponent } from './my-stems.component';

describe('MyStemsComponent', () => {
  let component: MyStemsComponent;
  let fixture: ComponentFixture<MyStemsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MyStemsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MyStemsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
