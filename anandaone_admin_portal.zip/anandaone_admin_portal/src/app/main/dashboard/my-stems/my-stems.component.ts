import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-stems',
  templateUrl: './my-stems.component.html',
  styleUrls: ['./my-stems.component.css']
})
export class MyStemsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
