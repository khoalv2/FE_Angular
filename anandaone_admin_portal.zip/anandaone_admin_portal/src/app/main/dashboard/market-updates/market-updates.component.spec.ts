import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MarketUpdatesComponent } from './market-updates.component';

describe('MarketUpdatesComponent', () => {
  let component: MarketUpdatesComponent;
  let fixture: ComponentFixture<MarketUpdatesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MarketUpdatesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MarketUpdatesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
