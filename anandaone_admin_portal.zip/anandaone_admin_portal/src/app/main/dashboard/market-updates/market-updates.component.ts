import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-market-updates',
  templateUrl: './market-updates.component.html',
  styleUrls: ['./market-updates.component.css']
})
export class MarketUpdatesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
