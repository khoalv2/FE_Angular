import { path } from '@amcharts/amcharts4/core';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DeveloperProfileComponent } from './developer-profile/developer-profile.component';


const routes: Routes = [
  {
    path: '',
    component: DeveloperProfileComponent,
    data: {
      title: 'Developer Profile'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class DeveloperProfileRoutingModule { }
