import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { DeveloperProfileRoutingModule } from './developer-profile-routing.module';
import { DeveloperProfileComponent } from './developer-profile/developer-profile.component';


@NgModule({
  declarations: [DeveloperProfileComponent],
  imports: [
    CommonModule,
    DeveloperProfileRoutingModule
  ]
})
export class DeveloperProfileModule { }
