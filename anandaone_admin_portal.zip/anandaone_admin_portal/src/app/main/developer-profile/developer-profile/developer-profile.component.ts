import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-developer-profile',
  templateUrl: './developer-profile.component.html',
  styleUrls: ['./developer-profile.component.scss']
})
export class DeveloperProfileComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
