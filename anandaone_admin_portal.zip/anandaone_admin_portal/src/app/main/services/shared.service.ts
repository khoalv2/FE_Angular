import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { CONSTANTS } from '../const/constants';

@Injectable()
export class SharedService {
    private message = new BehaviorSubject(CONSTANTS.ProjectType.AMC);
    sharedMessage = this.message.asObservable();

    constructor() {

    }

    nextMessage(message: string) {
        this.message.next(message)
    }
}