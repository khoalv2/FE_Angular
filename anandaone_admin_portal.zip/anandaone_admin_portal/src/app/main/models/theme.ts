export interface Theme {
    name: string;
    properties: any;
}

export const light: Theme = {
    name: 'light',
    properties: {
        // Core
        '--btn-inactive': '#D9D9D9',
        '--btn-active': '#0A2341',
        '--btn-text-inactive': '#0A2341',
        '--btn-text-active': '#FFFFFF',

        // Icon dropdown
        '--icon-dropdown': 'url(/../assets/img/icons/light/core/dropdown.svg)',
        // Icon sidebar
        '--icon-developer-profile': 'url(/../assets/img/icons/light/core/sb-developer-profile.svg)',
        '--icon-developer-profile-active': 'url(/../assets/img/icons/light/core/sb-developer-profile-active.svg)',
        '--icon-brand': 'url(/../assets/img/icons/light/core/sb-brand.svg)',
        '--icon-brand-active': 'url(/../assets/img/icons/light/core/sb-brand-active.svg)',
        '--icon-project-info': 'url(/../assets/img/icons/light/core/sb-project-info.svg)',
        '--icon-project-info-active': 'url(/../assets/img/icons/light/core/sb-project-info-active.svg)',
        '--icon-message': 'url(/../assets/img/icons/light/core/sb-message.svg)',
        '--icon-message-active': 'url(/../assets/img/icons/light/core/sb-message-active.svg)',
        '--icon-customer-group': 'url(/../assets/img/icons/light/core/sb-customer-group.svg)',
        '--icon-customer-group-active': 'url(/../assets/img/icons/light/core/sb-customer-group-active.svg)',
        '--icon-news': 'url(/../assets/img/icons/light/core/sb-news.svg)',
        '--icon-news-active': 'url(/../assets/img/icons/light/core/sb-news-active.svg)',
        '--icon-amc-reward-point': 'url(/../assets/img/icons/light/core/sb-amc-reward-point.svg)',
        '--icon-amc-reward-point-active': 'url(/../assets/img/icons/light/core/sb-amc-reward-point-active.svg)',
        '--icon-privilege': 'url(/../assets/img/icons/light/core/sb-privilege.svg)',
        '--icon-privilege-active': 'url(/../assets/img/icons/light/core/sb-privilege-active.svg)',
        '--icon-privilege-shop': 'url(/../assets/img/icons/light/core/sb-privilege-shop.svg)',
        '--icon-privilege-shop-active': 'url(/../assets/img/icons/light/core/sb-privilege-shop-active.svg)',
        '--icon-agreement': 'url(/../assets/img/icons/light/core/sb-agreement.svg)',
        '--icon-agreement-active': 'url(/../assets/img/icons/light/core/sb-agreement-active.svg)',
        '--icon-payment-file': 'url(/../assets/img/icons/light/core/sb-payment-file.svg)',
        '--icon-payment-file-active': 'url(/../assets/img/icons/light/core/sb-payment-file-active.svg)',
        '--icon-recurring': 'url(/../assets/img/icons/light/core/sb-recurring.svg)',
        '--icon-recurring-active': 'url(/../assets/img/icons/light/core/sb-recurring-active.svg)',
        '--icon-report': 'url(/../assets/img/icons/light/core/sb-report.svg)',
        '--icon-report-active': 'url(/../assets/img/icons/light/core/sb-report-active.svg)',
        '--icon-customer-list': 'url(/../assets/img/icons/light/core/sb-customer-list.svg)',
        '--icon-customer-list-active': 'url(/../assets/img/icons/light/core/sb-customer-list-active.svg)',
        '--icon-project-interest': 'url(/../assets/img/icons/light/core/sb-project-interest.svg)',
        '--icon-project-interest-active': 'url(/../assets/img/icons/light/core/sb-project-interest-active.svg)',

        '--icon-news-annoucements': 'url(/../assets/img/icons/light/core/sb-news-annoucements.svg)',
        '--icon-news-annoucements-active': 'url(/../assets/img/icons/light/core/sb-news-annoucements-active.svg)',
        '--icon-promotion': 'url(/../assets/img/icons/light/core/sb-promotion.svg)',
        '--icon-promotion-active': 'url(/../assets/img/icons/light/core/sb-promotion-active.svg)',
        '--icon-service': 'url(/../assets/img/icons/light/core/sb-service.svg)',
        '--icon-service-active': 'url(/../assets/img/icons/light/core/sb-service-active.svg)',

        // Custom
        '--bg-logo': '#0A2341',
        '--icon-logo': 'url(/../assets/img/icons/light/core/logo.svg)',
        '--bg-info-user': '#1558BE',
        '--icon-info-user': 'url(/../assets/img/icons/light/core/logo-user-info.svg)',
        '--color-sidebar': '#0A2341',
        '--color-sidebar-active': '#00B0F0',
    }
}

export const dark: Theme = {
    name: 'dark',
    properties: {
        // Icon dropdown
        '--icon-dropdown': 'url(/../assets/img/icons/light/core/dropdown.svg)',

        // Icon sidebar

        // Custom
        '--bg-logo': '#0A2341',
        '--icon-logo': 'url(/../assets/img/icons/dark/core/logo.svg)',
        '--bg-info-user': '#1558BE',
        '--icon-info-user': 'url(/../assets/img/icons/dark/core/logo-user-info.svg)',
    }
}