import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProjectInformationListComponent } from './project-information-list/project-information-list.component';


const routes: Routes = [
  {
    path: '',
    component: ProjectInformationListComponent,
    data: {
      title: 'Project Information List'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectInformationRoutingModule { }
