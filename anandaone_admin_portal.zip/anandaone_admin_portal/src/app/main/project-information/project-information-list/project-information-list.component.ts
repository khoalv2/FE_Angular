import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-information-list',
  templateUrl: './project-information-list.component.html',
  styleUrls: ['./project-information-list.component.scss']
})
export class ProjectInformationListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
