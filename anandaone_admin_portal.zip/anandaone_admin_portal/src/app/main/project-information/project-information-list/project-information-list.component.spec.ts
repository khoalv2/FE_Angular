import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectInformationListComponent } from './project-information-list.component';

describe('ProjectInformationListComponent', () => {
  let component: ProjectInformationListComponent;
  let fixture: ComponentFixture<ProjectInformationListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectInformationListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectInformationListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
