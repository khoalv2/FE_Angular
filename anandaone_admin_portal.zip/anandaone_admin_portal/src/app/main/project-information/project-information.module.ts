import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { ProjectInformationRoutingModule } from './project-information-routing.module';
import { ProjectInformationListComponent } from './project-information-list/project-information-list.component';


@NgModule({
  declarations: [ProjectInformationListComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    ProjectInformationRoutingModule
  ]
})
export class ProjectInformationModule { }
