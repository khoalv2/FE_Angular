import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { CustomerGroupRoutingModule } from './customer-group-routing.module';
import { CustomerGroupListComponent } from './customer-group-list/customer-group-list.component';


@NgModule({
  declarations: [CustomerGroupListComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    CustomerGroupRoutingModule
  ]
})
export class CustomerGroupModule { }
