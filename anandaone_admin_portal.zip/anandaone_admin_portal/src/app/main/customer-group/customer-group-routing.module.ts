import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { CustomerGroupListComponent } from "./customer-group-list/customer-group-list.component";

const routes: Routes = [
  {
    path: "",
    component: CustomerGroupListComponent,
    data: {
      title: "Customer Group",
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CustomerGroupRoutingModule {}
