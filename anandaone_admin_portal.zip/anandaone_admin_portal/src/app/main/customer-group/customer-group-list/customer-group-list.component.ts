import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-customer-group-list',
  templateUrl: './customer-group-list.component.html',
  styleUrls: ['./customer-group-list.component.scss']
})
export class CustomerGroupListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
