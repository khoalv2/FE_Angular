import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-agreement-list',
  templateUrl: './agreement-list.component.html',
  styleUrls: ['./agreement-list.component.scss']
})
export class AgreementListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
