import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AgreementListComponent } from './agreement-list/agreement-list.component';


const routes: Routes = [
  {
    path: '',
    component: AgreementListComponent,
    data: {
      title: 'Agreement'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AgreementRoutingModule { }
