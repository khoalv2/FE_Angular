import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PromotionListComponent } from './promotion-list/promotion-list.component';


const routes: Routes = [
  {
    path: '',
    component: PromotionListComponent,
    data: {
      title: 'Promotions'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PromotionsRoutingModule { }
