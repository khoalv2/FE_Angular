import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { ProjectInterestRoutingModule } from './project-interest-routing.module';
import { ProjectInterestListComponent } from './project-interest-list/project-interest-list.component';


@NgModule({
  declarations: [ProjectInterestListComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    ProjectInterestRoutingModule
  ]
})
export class ProjectInterestModule { }
