import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ProjectInterestListComponent } from './project-interest-list.component';

describe('ProjectInterestListComponent', () => {
  let component: ProjectInterestListComponent;
  let fixture: ComponentFixture<ProjectInterestListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ProjectInterestListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ProjectInterestListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
