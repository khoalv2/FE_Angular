import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-project-interest-list',
  templateUrl: './project-interest-list.component.html',
  styleUrls: ['./project-interest-list.component.scss']
})
export class ProjectInterestListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
