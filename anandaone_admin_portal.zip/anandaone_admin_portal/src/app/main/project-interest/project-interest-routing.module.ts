import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProjectInterestListComponent } from './project-interest-list/project-interest-list.component';


const routes: Routes = [
  {
    path: '',
    component: ProjectInterestListComponent,
    data: {
      title: 'Project Interest'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProjectInterestRoutingModule { }
