import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privilege-list',
  templateUrl: './privilege-list.component.html',
  styleUrls: ['./privilege-list.component.scss']
})
export class PrivilegeListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
