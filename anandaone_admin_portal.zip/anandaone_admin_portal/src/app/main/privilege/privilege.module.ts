import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';

import { PrivilegeRoutingModule } from './privilege-routing.module';
import { PrivilegeListComponent } from './privilege-list/privilege-list.component';


@NgModule({
  declarations: [PrivilegeListComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    PrivilegeRoutingModule
  ]
})
export class PrivilegeModule { }
