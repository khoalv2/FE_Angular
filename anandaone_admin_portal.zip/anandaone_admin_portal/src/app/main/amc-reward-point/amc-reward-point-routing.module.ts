import { NgModule } from "@angular/core";
import { Routes, RouterModule } from "@angular/router";
import { AmcRewardPointListComponent } from "./amc-reward-point-list/amc-reward-point-list.component";

const routes: Routes = [
  {
    path: "",
    component: AmcRewardPointListComponent,
    data: {
      title: "AMC Reward Point",
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class AmcRewardPointRoutingModule {}
