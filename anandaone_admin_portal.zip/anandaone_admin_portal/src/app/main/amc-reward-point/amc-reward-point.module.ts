import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule } from 'ngx-bootstrap/modal';

import { AmcRewardPointRoutingModule } from './amc-reward-point-routing.module';
import { AmcRewardPointListComponent } from './amc-reward-point-list/amc-reward-point-list.component';


@NgModule({
  declarations: [AmcRewardPointListComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    ModalModule.forRoot(),
    AmcRewardPointRoutingModule
  ]
})
export class AmcRewardPointModule { }
