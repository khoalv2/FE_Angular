import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-amc-reward-point-list',
  templateUrl: './amc-reward-point-list.component.html',
  styleUrls: ['./amc-reward-point-list.component.scss']
})
export class AmcRewardPointListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
