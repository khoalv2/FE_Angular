import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AmcRewardPointListComponent } from './amc-reward-point-list.component';

describe('AmcRewardPointListComponent', () => {
  let component: AmcRewardPointListComponent;
  let fixture: ComponentFixture<AmcRewardPointListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AmcRewardPointListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AmcRewardPointListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
