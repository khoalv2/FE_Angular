import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TabsModule } from 'ngx-bootstrap/tabs';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { ModalModule } from 'ngx-bootstrap/modal';

import { NewsAnnoucementsRoutingModule } from './news-annoucements-routing.module';
import { NewsAnnoucementsComponent } from './news-annoucements/news-annoucements.component';


@NgModule({
  declarations: [NewsAnnoucementsComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    TabsModule.forRoot(),
    PaginationModule.forRoot(),
    ModalModule.forRoot(),
    NewsAnnoucementsRoutingModule
  ]
})
export class NewsAnnoucementsModule { }
