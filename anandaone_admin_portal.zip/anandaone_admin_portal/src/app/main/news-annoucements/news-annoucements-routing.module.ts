import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { NewsAnnoucementsComponent } from './news-annoucements/news-annoucements.component';


const routes: Routes = [
  {
    path: '',
    component: NewsAnnoucementsComponent,
    data: {
      title: 'News'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class NewsAnnoucementsRoutingModule { }
