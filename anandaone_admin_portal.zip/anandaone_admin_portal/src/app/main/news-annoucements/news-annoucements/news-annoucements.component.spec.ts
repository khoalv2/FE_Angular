import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NewsAnnoucementsComponent } from './news-annoucements.component';

describe('NewsAnnoucementsComponent', () => {
  let component: NewsAnnoucementsComponent;
  let fixture: ComponentFixture<NewsAnnoucementsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NewsAnnoucementsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NewsAnnoucementsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
