import { Component } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';

@Component({
  templateUrl: 'resetpassword.component.html',
  styleUrls: ['resetpassword.component.css']
})
export class ResetPasswordComponent {
  resetForm: FormGroup;
  loading = false;
  submitted = false;
  returnUrl: string;
  error = '';
  constructor(  private formBuilder: FormBuilder) { }


  ngOnInit() {
    this.resetForm = this.formBuilder.group({
        username: ['', Validators.required]
    });


}


}
