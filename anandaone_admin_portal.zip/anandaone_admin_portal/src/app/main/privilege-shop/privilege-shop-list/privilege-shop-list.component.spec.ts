import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PrivilegeShopListComponent } from './privilege-shop-list.component';

describe('PrivilegeShopListComponent', () => {
  let component: PrivilegeShopListComponent;
  let fixture: ComponentFixture<PrivilegeShopListComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PrivilegeShopListComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PrivilegeShopListComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
