import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-privilege-shop-list',
  templateUrl: './privilege-shop-list.component.html',
  styleUrls: ['./privilege-shop-list.component.scss']
})
export class PrivilegeShopListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
