import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { PrivilegeShopListComponent } from './privilege-shop-list/privilege-shop-list.component';


const routes: Routes = [
  {
    path: '',
    component: PrivilegeShopListComponent,
    data: {
      title: 'Privilege Shop'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PrivilegeShopRoutingModule { }
