import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';


import { PrivilegeShopRoutingModule } from './privilege-shop-routing.module';
import { PrivilegeShopListComponent } from './privilege-shop-list/privilege-shop-list.component';


@NgModule({
  declarations: [PrivilegeShopListComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    PrivilegeShopRoutingModule
  ]
})
export class PrivilegeShopModule { }
