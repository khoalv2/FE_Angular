import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BrandComponent } from './brand.component';
import { BrandRoutingModule } from './brand.routing.module';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { FormsModule } from '@angular/forms';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';


@NgModule({
  declarations: [BrandComponent],
  imports: [
    BrandRoutingModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    FormsModule
  ]
})
export class BrandModule { }


