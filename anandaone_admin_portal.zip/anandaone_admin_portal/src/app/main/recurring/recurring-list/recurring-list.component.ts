import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-recurring-list',
  templateUrl: './recurring-list.component.html',
  styleUrls: ['./recurring-list.component.scss']
})
export class RecurringListComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
