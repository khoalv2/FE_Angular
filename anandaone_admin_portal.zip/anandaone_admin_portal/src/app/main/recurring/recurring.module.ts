import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { PaginationModule } from 'ngx-bootstrap/pagination';
import { BsDropdownModule } from 'ngx-bootstrap/dropdown';
import { BsDatepickerModule } from 'ngx-bootstrap/datepicker';

import { RecurringRoutingModule } from './recurring-routing.module';
import { RecurringListComponent } from './recurring-list/recurring-list.component';


@NgModule({
  declarations: [RecurringListComponent],
  imports: [
    CommonModule,
    BsDropdownModule.forRoot(),
    PaginationModule.forRoot(),
    BsDatepickerModule.forRoot(),
    RecurringRoutingModule
  ]
})
export class RecurringModule { }
