import { CommonModule } from '@angular/common';
import { ModuleWithProviders, NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ListPoolComponent } from './list-pool/list-pool.component';

@NgModule({
    imports: [
        CommonModule,
        ReactiveFormsModule,
        FormsModule,
    ],
    declarations: [
        ListPoolComponent
    ],
    exports: [
        CommonModule,
        ReactiveFormsModule,
        ListPoolComponent
    ]
})

export class ComponentsModule { }
