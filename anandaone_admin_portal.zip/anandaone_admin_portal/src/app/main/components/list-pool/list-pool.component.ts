import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-pool',
  templateUrl: './list-pool.component.html',
  styleUrls: ['./list-pool.component.css']
})
export class ListPoolComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
