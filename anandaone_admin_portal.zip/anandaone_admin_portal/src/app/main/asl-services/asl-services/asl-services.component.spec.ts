import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AslServicesComponent } from './asl-services.component';

describe('AslServicesComponent', () => {
  let component: AslServicesComponent;
  let fixture: ComponentFixture<AslServicesComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AslServicesComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AslServicesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
