import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AslServicesComponent } from './asl-services/asl-services.component';


const routes: Routes = [
  {
    path: '',
    component: AslServicesComponent,
    data: {
      title: 'Services'
    }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AslServicesRoutingModule { }
