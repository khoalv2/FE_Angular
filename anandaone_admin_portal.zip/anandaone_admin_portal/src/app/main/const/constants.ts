export const CONSTANTS = {
    ProjectType: {
        ASL: 'ASL',
        AMC: 'AMC'
    }
}