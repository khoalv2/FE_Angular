
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

// Import Containers
import { DefaultLayoutComponent } from './containers';

import { P404Component } from './main/error/404.component';
import { P500Component } from './main/error/500.component';
import { LoginComponent } from './main/login/login.component';
import { AuthGuard } from './main/auth/auth.guard';
import { ResetPasswordComponent } from './main/resetPassword/resetPassword.component';
import { BrandComponent } from './main/brand/brand.component';


export const routes: Routes = [
  {
    path: '',
    redirectTo: 'dashboard',
    pathMatch: 'full',
    canActivate: [AuthGuard]
  },
  {
    path: '404',
    component: P404Component,
    data: {
      title: 'Page 404'
    }
  },
  {
    path: '500',
    component: P500Component,
    data: {
      title: 'Page 500'
    }
  },
  {
    path: 'login',
    component: LoginComponent,
    data: {
      title: 'Login Page'
    }
  },
  {
    path: 'resetpass',
    component: ResetPasswordComponent,
    data: {
      title: 'Forgot Pasword'
    }
  },
  {
    path: '',
    component: DefaultLayoutComponent,
    data: {
      title: 'Home'
    },

    canActivate: [AuthGuard],
    children: [
      {
        path: 'dashboard',
        loadChildren: () => import('./main/dashboard/dashboard.module').then(m => m.DashboardModule)
      },

      {
        path: 'brand',
        loadChildren: () => import('./main/brand/brand.module').then(m => m.BrandModule)
      },
      {
        path: 'earnings',
        loadChildren: () => import('./main/earnings/earnings.module').then(m => m.EarningsModule)
      },
      {
        path: 'base',
        loadChildren: () => import('./main/base/base.module').then(m => m.BaseModule)
      },
      {
        path: 'base',
        loadChildren: () => import('./main/base/base.module').then(m => m.BaseModule)
      },
      {
        path: 'buttons',
        loadChildren: () => import('./main/buttons/buttons.module').then(m => m.ButtonsModule)
      },
      {
        path: 'charts',
        loadChildren: () => import('./main/chartjs/chartjs.module').then(m => m.ChartJSModule)
      },

      {
        path: 'icons',
        loadChildren: () => import('./main/icons/icons.module').then(m => m.IconsModule)
      },
      {
        path: 'notifications',
        loadChildren: () => import('./main/notifications/notifications.module').then(m => m.NotificationsModule)
      },
      {
        path: 'theme',
        loadChildren: () => import('./main/theme/theme.module').then(m => m.ThemeModule)
      },
      {
        path: 'widgets',
        loadChildren: () => import('./main/widgets/widgets.module').then(m => m.WidgetsModule)
      },
      {
        path: 'project-information',
        loadChildren: () => import('./main/project-information/project-information.module').then(m => m.ProjectInformationModule)
      },
      {
        path: 'message',
        loadChildren: () => import('./main/message/message.module').then(m => m.MessageModule),
      },
      {
        path: 'customer-group',
        loadChildren: () => import('./main/customer-group/customer-group.module').then(m => m.CustomerGroupModule),
      },
      {
        path: 'news',
        loadChildren: () => import('./main/news/news.module').then(m => m.NewsModule),
      },
      {
        path: 'amc-reward-point',
        loadChildren: () => import('./main/amc-reward-point/amc-reward-point.module').then(m => m.AmcRewardPointModule),
      },
      {
        path: 'privilege',
        loadChildren: () => import('./main/privilege/privilege.module').then(m => m.PrivilegeModule),
      },
      {
        path: 'privilege-shop',
        loadChildren: () => import('./main/privilege-shop/privilege-shop.module').then(m => m.PrivilegeShopModule),
      },
      {
        path: 'agreement',
        loadChildren: () => import('./main/agreement/agreement.module').then(m => m.AgreementModule),
      },
      {
        path: 'project-interest',
        loadChildren: () => import('./main/project-interest/project-interest.module').then(m => m.ProjectInterestModule),
      },
      {
        path: 'customer-list',
        loadChildren: () => import('./main/customer-list/customer-list.module').then(m => m.CustomerListModule),
      },
      {
        path: 'payment-file',
        loadChildren: () => import('./main/payment-file/payment-file.module').then(m => m.PaymentFileModule),
      },
      {
        path: 'recurring',
        loadChildren: () => import('./main/recurring/recurring.module').then(m => m.RecurringModule),
      },
      {
        path: 'report',
        loadChildren: () => import('./main/report/report.module').then(m => m.ReportModule),
      },
      {
        path: 'news-annoucements',
        loadChildren: () => import('./main/news-annoucements/news-annoucements.module').then(m => m.NewsAnnoucementsModule),
      },
      {
        path: 'promotion',
        loadChildren: () => import('./main/promotions/promotions.module').then(m => m.PromotionsModule),
      },
      {
        path: 'developer-profile',
        loadChildren: () => import('./main/developer-profile/developer-profile.module').then(m => m.DeveloperProfileModule),
      },
      {
        path: 'service',
        loadChildren: () => import('./main/asl-services/asl-services.module').then(m => m.AslServicesModule),
      },
    ]
  },
  { path: '**', component: P404Component },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
