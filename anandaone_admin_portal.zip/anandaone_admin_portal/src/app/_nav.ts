import { INavData } from '@coreui/angular';
import { CONSTANTS } from './main/const/constants';

export const navItems: INavData[] = [
  //AMC
  {
    name: 'Developer Profile',
    url: '/developer-profile',
    icon: 'fa fa-developer-profile',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-developer-profile'
  },
  {
    name: 'Brand',
    url: '/brand',
    icon: 'fa fa-brand',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-brand'
  },
  {
    name: 'Project Information',
    url: '/project-information',
    icon: 'fa fa-project-info',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-project-information'
  },
  {
    name: 'Message',
    url: '/message',
    icon: 'fa fa-message',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-message'
  },
  {
    name: 'Customer Group',
    url: '/customer-group',
    icon: 'fa fa-customer-group',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-customer-group'
  },
  {
    name: 'News',
    url: '/news',
    icon: 'fa fa-news',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-news'
  },
  {
    name: 'AMC Reward Point',
    url: '/amc-reward-point',
    icon: 'fa fa-amc-reward-point',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-amc-reward-point'
  },
  {
    name: 'Privilege',
    url: '/privilege',
    icon: 'fa fa-privilege',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-privilege'
  },
  {
    name: 'Privilege Shop',
    url: '/privilege-shop',
    icon: 'fa fa-privilege-shop',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-privilege-shop'
  },
  {
    name: 'Agreement',
    url: '/agreement',
    icon: 'fa fa-agreement',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-agreement'
  },
  {
    name: 'Project Interest',
    url: '/project-interest',
    icon: 'fa fa-project-interest',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-project-interest'
  },
  {
    name: 'Customer List',
    url: '/customer-list',
    icon: 'fa fa-customer-list',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-customer-list'
  },
  {
    name: 'Payment File',
    url: '/payment-file',
    icon: 'fa fa-payment-file',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-payment-file'
  },
  {
    name: 'Recurring',
    url: '/recurring',
    icon: 'fa fa-recurring',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-recurring'
  },
  {
    name: 'Report',
    url: '/report',
    icon: 'fa fa-report',
    variant: CONSTANTS.ProjectType.AMC,
    class: 'sbm-report'
  },
  //ASL
  {
    name: 'News & Annoucements',
    url: '/news-annoucements',
    icon: 'fa fa-news-annoucements',
    variant: CONSTANTS.ProjectType.ASL,
    class: 'sbm-news-annoucements'
  },
  {
    name: 'Promotion',
    url: '/promotion',
    icon: 'fa fa-promotion',
    variant: CONSTANTS.ProjectType.ASL,
    class: 'sbm-promotion'
  },
  {
    name: 'Service',
    url: '/service',
    icon: 'fa fa-service',
    variant: CONSTANTS.ProjectType.ASL,
    class: 'sbm-service'
  },

];
